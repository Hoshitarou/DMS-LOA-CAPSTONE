using LOA_DMS_Capstone.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace LOA_DMS_Capstone.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

     

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Window1()
        {
            return View();
        }

        public IActionResult W1Upload()
        {
            return View();
        }

        public IActionResult W1Transac()
        {
            return View();
        }

        public IActionResult W1Track()
        {
            return View();
        }


        public IActionResult Released()
        {
            return View();
        }

        public IActionResult ReRecord()
        {
            return View();
        }
        public IActionResult Pulled()
        {
            return View();
        }

        public IActionResult Checkin()
        {
            return View();
        }

        public IActionResult CheckList()
        {
            return View();
        }

        public IActionResult StatTransac() 
        {
            return View();  
        }

        public IActionResult StatReqs() 
        {
            return View();
        }

        public IActionResult HRview() 
        {
			return View();
		}

        public IActionResult Dashboard ()
        {
            return View();
        }

        public IActionResult ActivityLogs()
        {
            return View();
        }

        public IActionResult UserM()
        {
            return View();
        }

        public IActionResult DocuM()
        {
            return View();
        }

        public IActionResult LockA()
        {
            return View();
        }

        public IActionResult Deac()
        {
            return View();
        }

        public IActionResult Modify()
        {
            return View();
        }
        public IActionResult ArchivedD()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
